PartCQuestion1.scala Trivial Page Rank Application
PartCQuestion2.scala Use Range Partitioner
partCQuestion3.scala cache the (val graph)
